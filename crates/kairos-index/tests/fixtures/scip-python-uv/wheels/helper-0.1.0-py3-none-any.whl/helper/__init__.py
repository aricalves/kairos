def greet():
    return "hi"
